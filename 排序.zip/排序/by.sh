echo 编译并执行这个工程啊啊啊啊呜呜呜

gcc -c fuzhu.c paixu.c
gcc -c main.c
gcc -o runP main.o fuzhu.o paixu.o
./runP